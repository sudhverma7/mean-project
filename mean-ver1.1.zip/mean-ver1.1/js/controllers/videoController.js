app.controller('videoController',function($scope,videoURL){
    $scope.video = videoURL;
});